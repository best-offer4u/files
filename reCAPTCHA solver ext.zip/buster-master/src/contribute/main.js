import Vue from 'vue';

import App from './App';

var vm = new Vue({
  el: '#app',
  render: h => h(App)
});
